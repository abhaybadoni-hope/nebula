# NEBULA Phase 2 — Experimental Artifacts & System Source

This package was assembled for Person B by copying existing repository
files **byte-for-byte** (verified via SHA-256 comparison against the
source repository — see `PHASE2_SHA256SUMS.txt` alongside the ZIP). No
historical experiment file was edited, regenerated, or reinterpreted to
build this package. No experiment was rerun. Missing metadata is marked
`NOT RECORDED`, never guessed.

Repository-relative paths are preserved exactly as they exist in the
NEBULA repository (`results/...`, `circuits/...`, `rl/...`, etc.) — this
package is a curated subset of the real repository tree, not a
reorganized copy.

## What's in here

1. **`results/`** — the full set of experimental data files backing every
   reported result: PPO/RS/CEM logs, checkpoints, PVT runs (original,
   diagnosis, reproduction check, full rerun), benchmark summaries,
   manifests, schematics, crash logs, and the one specifically-reported
   real-SPICE UI run (`web_ui_runs/ed91dd5617fa4c99b9539931c1c25ed6.*`).
   Ad-hoc UI-development test artifacts under `web_ui_runs/` (synthetic
   dry runs, curl smoke tests made while building the UI itself) are
   **not** included — they are not tied to any reported result.
2. **`circuits/`, `channels/`** — the SPICE bench/block files and channel
   input files (`.s4p`, `.json`) every experiment in `results/` was
   evaluated against.
3. **`docs/`** — the full experimental log (`autockt-mapping.md`, 23
   sections) and the final competition audit
   (`FINAL_TECHNICAL_AUDIT.md`), plus two earlier design-decision docs.
4. **`requirements.txt`** — the repository's own pinned dependency file
   (note: it pins only `numpy`; PyTorch is a real, separate runtime
   dependency not captured in this file — see
   `PHASE2_ENVIRONMENT.md`-equivalent section in the outer artifact
   index for what was and wasn't independently verifiable).
5. **`experiments/`, `rl/`, `simulator/`, `analysis/`** — the complete
   current competition/demo pipeline and UI source (`web_ui.py`,
   `run_autockt_pipeline.py`, and every module they import), plus the
   separate historical scripts that produced the RS/CEM/unseen-target/
   R-C-sweep results (`receiver_search.py`, `train_cem.py`,
   `controlled_unseen_target_eval.py`, `rc_counterfactual_sweep.py`) —
   not imported by the current pipeline, but the exact source that
   generated the packaged historical data.
6. **`tests/`** — the SPICE-free regression tests covering every module
   above (UI, pipeline, and each analysis/RL module included).

See the outer `PHASE2_ARTIFACT_INDEX.md` (outside this ZIP, alongside it)
for a full file-by-file table: category, purpose, original/copied status,
pass/fail/incomplete status, seed, and relationship to reported results.

## How to run the UI (the current competition/demo system)

```
python experiments/web_ui.py --port 8001
```
then open `http://127.0.0.1:8001`. Requires the same Python environment
this repository was developed in (torch, numpy, and a working `ngspice`
on `PATH` for real-backend runs — see the outer index's environment
section for exactly what was verified and what was not). Full usage
instructions: `docs/FINAL_TECHNICAL_AUDIT.md`, section 10.

## The PVT rerun sequence (§3 of Person B's request) — preserved exactly

1. **Original minimal-27 run**: `results/design_a_pvt_minimal27.jsonl` —
   **23/27 PASS**. Preserved unmodified; this is the historical record,
   never overwritten.
2. **Targeted diagnosis of the 4 failures**:
   `results/design_a_pvt_failure_diagnosis.jsonl` — full per-stage detail
   captured for the same design at the same 4 conditions.
3. **Targeted reproduction check** (same 4 conditions, identical code
   path as step 1): `results/design_a_pvt_failure_reproduction_check.jsonl`
   — **4/4 PASS**.
4. **Complete 27-point rerun**: `results/design_a_pvt_minimal27_rerun.jsonl`
   — **27/27 PASS**, 138.4 minutes wall-clock.

Both `design_a_pvt_minimal27.jsonl` (23/27) and
`design_a_pvt_minimal27_rerun.jsonl` (27/27) are included, unmodified,
side by side — the original is not replaced or deleted.

## Benchmark artifacts (§4 of Person B's request) — kept distinct

| Experiment | File | Result |
|---|---|---|
| Random Search (fair) | `results/receiver_random_search_20_seed123.jsonl` + `.manifest.json` + `.summary.json` | seed 123, n=20, 1/20 (5%), 9 evals to first success |
| CEM, unbiased init (fair) | `results/cem_unbiased_seed123.jsonl` | seed 123, n=20 (4x5, elite=2, mean=0, std=0.577), 0/20 |
| CEM, incomplete/warm-started (**NOT** a fair benchmark — kept for reproducibility only) | `results/cem_baseline_3x10.jsonl` | 13/30, warm-started — explicitly excluded from fair comparisons in the project's own analysis |
| CEM, graded-fitness fix | `results/cem_graded_unbiased_seed123.jsonl` | 0/20 — the fix is independently verified correct (see `tests/test_train_cem.py`) but never exercised in this run, since no candidate reached a gradient-bearing stage |
| Fair PPO, no warm start, grid-center, horizon=1 | `results/autockt_fair_headtohead_seed123.jsonl` | n=20, 0/20, all failed at `dc` |
| PPO learning evidence, single-target | `results/autockt_normfix_confirmation.jsonl` | satisfaction 0.667→1.0, reward 5.84→10.0 |
| PPO learning evidence, mixed-target | `results/autockt_mixed_target_confirmation.jsonl` (+ checkpoint `autockt_mixed_target_confirmation_policy.pt`) | satisfaction 0.333→1.0, reward 1.51→10.0; per-update rewards 2.83, 5.33, 2.33, 4.96, 4.67, 2.96 |
| PPO unseen-target generalization | `results/controlled_unseen_target_generalization.jsonl` | 1 win / 6 ties / 3 losses |
| Consolidated benchmark report (recomputes nothing new, cross-checks the above) | `results/benchmark_report.json` | — |

**Fair benchmark, warm-started, and learning-evidence experiments are
kept as separate files and never merged** — see
`docs/FINAL_TECHNICAL_AUDIT.md` section 5 for the explicit distinction
and why combining them would be misleading.

## Design A and the feasible-design catalog (§5)

`results/feasible_design_catalog.jsonl` (8 designs), `results/design_a_final_specification.json`
(the authoritative PASS/FAIL/NOT CLAIMED report), and the exported
schematics under `results/schematics/`.

## The successful real-SPICE UI run (§6)

`results/web_ui_runs/ed91dd5617fa4c99b9539931c1c25ed6.json` (the
pipeline's own raw output JSON) and
`..._schematic.spice` (the exported netlist). Not recreated for this
package — this is the original output file from that run.

## Historical failures / incomplete / diagnostic runs (§7)

- `results/pipeline_real_spice_smoke_test_CRASH_LOG.txt`,
  `..._CRASH_LOG_2.txt`, `results/hd3_noise_validation_CRASH_LOG.txt` —
  three real SIGSEGV (exit 139) crash logs, including exact commands and
  (for the third) a partial Python fault-handler stack trace that
  identified the crash's likely mechanism (see
  `docs/FINAL_TECHNICAL_AUDIT.md` section 4.E).
- `results/cem_baseline_3x10.jsonl` — incomplete (13/30), warm-started;
  kept, never treated as a fair benchmark.
- `results/design_a_pvt_minimal27.jsonl` — the original 23/27, preserved
  as historical inconsistency evidence, not deleted.
- `results/design_a_pvt_failure_diagnosis.jsonl`,
  `results/design_a_pvt_failure_reproduction_check.jsonl` — the
  diagnostic runs that investigated the 4 original PVT failures.

No failed or incomplete run was deleted to build this package.
